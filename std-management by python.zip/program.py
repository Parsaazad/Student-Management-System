from tkinter import *
from tkinter import messagebox
import subprocess

def validate_email(email):
    if "@gmail.com" in email:
        return True
    else:
        return False

def register():
    screen2 = Toplevel(screen)
    screen2.title("Registration")
    screen2.geometry("800x650+150+80")
    screen2.configure(bg="#d7dae2")

    global first_name
    global last_name
    global email
    global username 
    global password

    first_name = StringVar()
    last_name = StringVar()
    email = StringVar()
    username = StringVar()
    password = StringVar()

    Label(screen2, text="Registration", font=("arial", 50, 'bold'), fg="black", bg="#d7dae2").pack(pady=50)

    frame = Frame(screen2, bg="#d7dae2")
    frame.pack(pady=20)

    Label(frame, text="First Name", font=("arial", 30, "bold"), bg="#d7dae2").grid(row=0, column=0, padx=10, pady=10)
    Entry(frame, textvariable=first_name, width=15, bd=5, font=("arial", 20)).grid(row=0, column=1, padx=10, pady=10)

    Label(frame, text="Last Name", font=("arial", 30, "bold"), bg="#d7dae2").grid(row=1, column=0, padx=10, pady=10)
    Entry(frame, textvariable=last_name, width=15, bd=5, font=("arial", 20)).grid(row=1, column=1, padx=10, pady=10)

    Label(frame, text="Email", font=("arial", 30, "bold"), bg="#d7dae2").grid(row=2, column=0, padx=10, pady=10)
    Entry(frame, textvariable=email, width=15, bd=5, font=("arial", 20)).grid(row=2, column=1, padx=10, pady=10)

    Label(frame, text="Username", font=("arial", 30, "bold"), bg="#d7dae2").grid(row=3, column=0, padx=10, pady=10)
    Entry(frame, textvariable=username, width=15, bd=5, font=("arial", 20)).grid(row=3, column=1, padx=10, pady=10)

    Label(frame, text="Password", font=("arial", 30, "bold"), bg="#d7dae2").grid(row=4, column=0, padx=10, pady=10)
    Entry(frame, textvariable=password, width=15, bd=5, font=("arial", 20), show="*").grid(row=4, column=1, padx=10, pady=10)

    def register_user():
        if len(first_name.get()) < 1 or len(last_name.get()) < 1 or len(email.get()) < 1 or len(username.get()) < 1 or len(password.get()) < 8:
            messagebox.showerror("Invalid", "All fields are required and password must be at least 8 characters long.")
            return
        if not validate_email(email.get()):
            messagebox.showerror("Invalid", "Email must be a valid gmail.com address.")
            return
        with open("users.txt", "a") as file:
            file.write(f"{first_name.get()} {last_name.get()},{email.get()},{username.get()},{password.get()}\n")
        messagebox.showinfo("Success", "Registration successful!")
        screen2.destroy()

    Button(screen2, text="Register", height="2", width=23, bg="#ed3833", fg="white", bd=0, command=register_user).pack(pady=10)
    Button(screen2, text="Back", height="2", width=23, bg="#1089ff", fg="white", bd=0, command=screen2.destroy).pack(pady=10)

def login():
    screen3 = Toplevel(screen)
    screen3.title("Login")
    screen3.geometry("800x650+150+80")
    screen3.configure(bg="#d7dae2")

    global username_verify
    global password_verify

    username_verify = StringVar()
    password_verify = StringVar()

    Label(screen3, text="Login System", font=("arial", 50, 'bold'), fg="black", bg="#d7dae2").pack(pady=50)

    frame2 = Frame(screen3, bg="#d7dae2")
    frame2.pack(pady=20)

    Label(frame2, text="Username", font=("arial", 30, "bold"), bg="#d7dae2").grid(row=0, column=0, padx=10, pady=10)
    Entry(frame2, textvariable=username_verify, width=15, bd=5, font=("arial", 20)).grid(row=0, column=1, padx=10, pady=10)

    Label(frame2, text="Password", font=("arial", 30, "bold"), bg="#d7dae2").grid(row=1, column=0, padx=10, pady=10)
    Entry(frame2, textvariable=password_verify, width=15, bd=5, font=("arial", 20), show="*").grid(row=1, column=1, padx=10, pady=10)

    def login_user():
        username = username_verify.get()
        password = password_verify.get()

        with open("users.txt", "r") as file:
            for line in file:
                fields = line.strip().split(",")
                if len(fields) == 4 and fields[2] == username and fields[3] == password:
                    subprocess.run(['python', 'studentmanagement.py'])
                    return

        messagebox.showerror("Invalid", "Invalid username or password")

    Button(screen3, text="Login", height="2", width=23, bg="#ed3833", fg="white", bd=0, command=login_user).pack(pady=10)
    Button(screen3, text="Back", height="2", width=23, bg="#1089ff", fg="white", bd=0, command=screen3.destroy).pack(pady=10)
    Button(screen3, text="Register", height="2", width=23, bg="#00db56", fg="white", bd=0, command=register).pack(pady=10)

def main_screen():
    global screen
    screen = Tk()
    screen.geometry("800x650+150+80")
    screen.title("Login System")
    screen.configure(bg="#d7dae2")

    Label(text="Login System", font=("arial", 50, 'bold'), fg="black", bg="#d7dae2").pack(pady=50)

    Button(text="Login", height="2", width=30, bg="#ed3833", fg="white", bd=0, command=login).pack(pady=20)
    Button(text="Register", height="2", width=30, bg="#00db56", fg="white", bd=0, command=register).pack(pady=20)

    screen.mainloop()

main_screen()