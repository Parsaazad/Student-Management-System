#region Import Libraries
import tkinter as tk
from tkinter import ttk, messagebox
#endregion

#region Data
students = []
#endregion

#region Functions
def add_student():
    name = name_entry.get()
    last_name = last_name_entry.get()
    age = age_entry.get()
    national_code = national_code_entry.get()
    student_code = student_code_entry.get()
    gender = gender_var.get()
    phone = phone_entry.get()
    classroom = classroom_var.get()
    student_details = student_details_entry.get()

    if not name.isalpha() or not last_name.isalpha():
        messagebox.showerror("Error", "Name and Last Name should only contain letters.")
        return

    try:
        age = int(age)
        if age < 1 or age > 120:
            messagebox.showerror("Error", "Age should be between 1 and 120.")
            return
    except ValueError:
        messagebox.showerror("Error", "Age should be a number.")
        return

    if len(national_code) != 10 or not national_code.isdigit():
        messagebox.showerror("Error", "National Code should be 10 digits.")
        return

    if len(student_code) != 10 or not student_code.isdigit():
        messagebox.showerror("Error", "Student Code should be 10 digits.")
        return

    student = [name, last_name, age, national_code, student_code, gender, phone, classroom, student_details]
    students.append(student)
    messagebox.showinfo("Success", "Student added successfully.")
    populate_treeview()
    clear_entries()

def edit_student():
    selected_item = student_treeview.focus()
    if not selected_item:
        messagebox.showerror("Error", "Please select a student to edit.")
        return

    student_values = student_treeview.item(selected_item)['values']
    name_entry.delete(0, tk.END)
    name_entry.insert(0, student_values[0])
    last_name_entry.delete(0, tk.END)
    last_name_entry.insert(0, student_values[1])
    age_entry.delete(0, tk.END)
    age_entry.insert(0, student_values[2])
    national_code_entry.delete(0, tk.END)
    national_code_entry.insert(0, student_values[3])
    student_code_entry.delete(0, tk.END)
    student_code_entry.insert(0, student_values[4])
    gender_var.set(student_values[5])
    phone_entry.delete(0, tk.END)
    phone_entry.insert(0, student_values[6])
    classroom_var.set(student_values[7])
    student_details_entry.delete(0, tk.END)
    student_details_entry.insert(0, student_values[8])

def delete_student():
    selected_item = student_treeview.focus()
    if not selected_item:
        messagebox.showerror("Error", "Please select a student to delete.")
        return

    response = messagebox.askyesno("Confirm", "Are you sure you want to delete this student?")
    if response:
        student_treeview.delete(selected_item)
        students.remove(student_treeview.item(selected_item)['values'])
        messagebox.showinfo("Success", "Student deleted successfully.")
        clear_entries()

def clear_entries():
    name_entry.delete(0, tk.END)
    last_name_entry.delete(0, tk.END)
    age_entry.delete(0, tk.END)
    national_code_entry.delete(0, tk.END)
    student_code_entry.delete(0, tk.END)
    gender_var.set("Male")
    phone_entry.delete(0, tk.END)
    classroom_var.set("A")
    student_details_entry.delete(0, tk.END)

def populate_treeview():
    student_treeview.delete(*student_treeview.get_children())
    for student in students:
        student_treeview.insert('', 'end', values=student)
#endregion

#region Main Window
root = tk.Tk()
root.title("Student Management")
root.geometry("800x600")
root.configure(bg="#1c1c1c")
#endregion

#region Styles
style = ttk.Style()
style.theme_use("clam")
style.configure("TLabel", background="#1c1c1c", foreground="#ffffff", font=("Arial", 12))
style.configure("TEntry", fieldbackground="#2c2c2c", foreground="#ffffff", font=("Arial", 12))
style.configure("TButton", background="#4c4c4c", foreground="#ffffff", font=("Arial", 12))
style.configure("TRadiobutton", background="#1c1c1c", foreground="#ffffff", font=("Arial", 12))
style.configure("Treeview", fieldbackground="#2c2c2c", foreground="#ffffff", rowheight=25)
#endregion

#region Widgets
name_label = ttk.Label(root, text="Name:")
name_label.grid(row=0, column=0, padx=10, pady=10, sticky=tk.W)
name_entry = ttk.Entry(root)
name_entry.grid(row=0, column=1, padx=10, pady=10)

last_name_label = ttk.Label(root, text="Last Name:")
last_name_label.grid(row=1, column=0, padx=10, pady=10, sticky=tk.W)
last_name_entry = ttk.Entry(root)
last_name_entry.grid(row=1, column=1, padx=10, pady=10)

age_label = ttk.Label(root, text="Age:")
age_label.grid(row=2, column=0, padx=10, pady=10, sticky=tk.W)
age_entry = ttk.Entry(root)
age_entry.grid(row=2, column=1, padx=10, pady=10)

national_code_label = ttk.Label(root, text="National Code:")
national_code_label.grid(row=3, column=0, padx=10, pady=10, sticky=tk.W)
national_code_entry = ttk.Entry(root)
national_code_entry.grid(row=3, column=1, padx=10, pady=10)

student_code_label = ttk.Label(root, text="Student Code:")
student_code_label.grid(row=4, column=0, padx=10, pady=10, sticky=tk.W)
student_code_entry = ttk.Entry(root)
student_code_entry.grid(row=4, column=1, padx=10, pady=10)

gender_label = ttk.Label(root, text="Gender:")
gender_label.grid(row=5, column=0, padx=10, pady=10, sticky=tk.W)
gender_var = tk.StringVar()
gender_var.set("Male")
male_radio = ttk.Radiobutton(root, text="Male", variable=gender_var, value="Male")
male_radio.grid(row=5, column=1, padx=10, pady=10, sticky=tk.W)
female_radio = ttk.Radiobutton(root, text="Female", variable=gender_var, value="Female")
female_radio.grid(row=5, column=1, padx=100, pady=10, sticky=tk.W)
other_radio = ttk.Radiobutton(root, text="Other", variable=gender_var, value="Other")
other_radio.grid(row=5, column=1, padx=190, pady=10, sticky=tk.W)
phone_label = ttk.Label(root, text="Phone:")
phone_label.grid(row=6, column=0, padx=10, pady=10, sticky=tk.W)
phone_entry = ttk.Entry(root)
phone_entry.grid(row=6, column=1, padx=10, pady=10)

classroom_label = ttk.Label(root, text="Classroom:")
classroom_label.grid(row=7, column=0, padx=10, pady=10, sticky=tk.W)
classroom_var = tk.StringVar()
classroom_var.set("A")
classroom_a = ttk.Radiobutton(root, text="A", variable=classroom_var, value="A")
classroom_a.grid(row=7, column=1, padx=10, pady=10, sticky=tk.W)
classroom_b = ttk.Radiobutton(root, text="B", variable=classroom_var, value="B")
classroom_b.grid(row=7, column=1, padx=100, pady=10, sticky=tk.W)
classroom_c = ttk.Radiobutton(root, text="C", variable=classroom_var, value="C")
classroom_c.grid(row=7, column=1, padx=190, pady=10, sticky=tk.W)

student_details_label = ttk.Label(root, text="Student Details:")
student_details_label.grid(row=8, column=0, padx=10, pady=10, sticky=tk.W)
student_details_entry = ttk.Entry(root)
student_details_entry.grid(row=8, column=1, padx=10, pady=10)

add_button = ttk.Button(root, text="   Add   ", command=add_student)
add_button.grid(row=9, column=0, padx=10, pady=10)

edit_button = ttk.Button(root, text="   Edit   ", command=edit_student)
edit_button.grid(row=9, column=1, padx=10, pady=10)

delete_button = ttk.Button(root, text="   Delete   ", command=delete_student)
delete_button.grid(row=9, column=2, padx=10, pady=10)
#endregion

#region Treeview
student_treeview = ttk.Treeview(root, columns=("Name", "Last Name", "Age", "National Code", "Student Code", "Gender", "Phone", "Classroom", "Student Details"), show="headings")
student_treeview.grid(row=10, column=0, columnspan=4, padx=10, pady=10, sticky=tk.NSEW)

root.grid_rowconfigure(10, weight=1)
root.grid_columnconfigure(0, weight=1)
root.grid_columnconfigure(1, weight=1)
root.grid_columnconfigure(2, weight=1)
root.grid_columnconfigure(3, weight=1)

student_treeview.heading("Name", text="Name")
student_treeview.heading("Last Name", text="Last Name")
student_treeview.heading("Age", text="Age")
student_treeview.heading("National Code", text="National Code")
student_treeview.heading("Student Code", text="Student Code")
student_treeview.heading("Gender", text="Gender")
student_treeview.heading("Phone", text="Phone")
student_treeview.heading("Classroom", text="Classroom")
student_treeview.heading("Student Details", text="Student Details")

student_treeview.column("Name", width=100, anchor=tk.CENTER)
student_treeview.column("Last Name", width=100, anchor=tk.CENTER)
student_treeview.column("Age", width=50, anchor=tk.CENTER)
student_treeview.column("National Code", width=100, anchor=tk.CENTER)
student_treeview.column("Student Code", width=100, anchor=tk.CENTER)
student_treeview.column("Gender", width=80, anchor=tk.CENTER)
student_treeview.column("Phone", width=100, anchor=tk.CENTER)
student_treeview.column("Classroom", width=80, anchor=tk.CENTER)
student_treeview.column("Student Details", width=150, anchor=tk.CENTER)
#endregion

#region Start Main Loop
root.mainloop()
#endregion